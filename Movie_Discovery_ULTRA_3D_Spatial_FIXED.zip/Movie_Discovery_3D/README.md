# FRAME — Movie Discovery App | EG04

Giao diện khám phá phim phong cách 3D Neon Cinema, responsive cho desktop/tablet/mobile.

## Cấu trúc
- `index.html` — cấu trúc trang và modal chi tiết.
- `css/style.css` — CSS Grid, biến CSS, light/dark theme, hiệu ứng 3D và responsive.
- `js/app.js` — dữ liệu phim, tạo bộ lọc thể loại tự động, tìm kiếm debounce 400ms, lọc kết hợp, modal, localStorage.
- `images/poster-fallback.svg` — poster dự phòng nội bộ khi poster trực tuyến không tải được.

## Chạy thử
Mở thư mục trong VS Code, nhấp phải `index.html` → **Open with Live Server**. Không cần cài thư viện hay chạy backend. Ảnh poster chính tải từ TMDB nên cần Internet; nếu ảnh lỗi, giao diện tự hiển thị poster dự phòng cục bộ.

## Checklist yêu cầu EG04
- [x] HTML/CSS/JS tách thành file riêng.
- [x] CSS Grid cho sidebar và nội dung; responsive.
- [x] CSS Variables và nút chuyển sáng/tối.
- [x] Thẻ phim có poster, tên, năm, điểm đánh giá và hover.
- [x] Dữ liệu phim dạng mảng; thể loại tự tạo checkbox.
- [x] Tìm kiếm tiêu đề theo thời gian thực với debounce 400ms.
- [x] Kết hợp tìm kiếm và nhiều bộ lọc thể loại.
- [x] Modal có poster, mô tả, đạo diễn, diễn viên, thể loại.
- [x] Theme được lưu bằng localStorage.
- [x] Có poster fallback cục bộ trong `images/`.

## Deploy miễn phí bằng GitHub Pages
1. Tải **nội dung bên trong thư mục** lên repository GitHub.
2. Mở **Settings → Pages**.
3. Chọn **Deploy from a branch**, branch `main`, folder `/ (root)` rồi Save.
4. Chờ GitHub Pages xuất URL; mở URL kiểm tra trước khi nộp.

Có thể deploy nhanh bằng Netlify: kéo thư mục chứa `index.html`, `css/`, `js/`, `images/` vào trang deploy thủ công của Netlify.

## Trước khi nộp
- Đổi tên ZIP theo mẫu `MSSV_HoTen_bt40.zip`.
- Điền URL website đã deploy thật vào báo cáo.
- Thêm ảnh chụp màn hình sản phẩm và liên kết bài 37, 38, 39 theo thông tin của bạn.
