// Movie Discovery App — EG04
// Dữ liệu mẫu dùng cho bài thực hành. Poster tham khảo từ TMDB; cần Internet để tải ảnh.
const movies = [
  {
    id: "dune-part-two",
    title: "Dune: Part Two", year: 2024, rating: 8.5,
    genres: ["Khoa học viễn tưởng", "Phiêu lưu", "Hành động"],
    director: "Denis Villeneuve", cast: "Timothée Chalamet, Zendaya, Rebecca Ferguson",
    description: "Paul Atreides hợp nhất với Chani và người Fremen trong hành trình trả thù những kẻ đã hủy hoại gia đình anh, đồng thời đối mặt với lựa chọn có thể thay đổi số phận cả vũ trụ.",
    poster: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg"
  },
  {
    id: "oppenheimer",
    title: "Oppenheimer", year: 2023, rating: 8.3,
    genres: ["Chính kịch", "Lịch sử", "Giật gân"],
    director: "Christopher Nolan", cast: "Cillian Murphy, Emily Blunt, Robert Downey Jr.",
    description: "Chân dung J. Robert Oppenheimer và vai trò của ông trong Dự án Manhattan, nơi cuộc chạy đua tạo ra bom nguyên tử làm thay đổi lịch sử nhân loại.",
    poster: "https://image.tmdb.org/t/p/w500/ptpr0kGAckfQkJeJIfMZ4qK5j4.jpg"
  },
  {
    id: "spider-man-across-the-spider-verse",
    title: "Spider-Man: Across the Spider-Verse", year: 2023, rating: 8.6,
    genres: ["Hoạt hình", "Hành động", "Phiêu lưu", "Khoa học viễn tưởng"],
    director: "Joaquim Dos Santos, Kemp Powers, Justin K. Thompson", cast: "Shameik Moore, Hailee Steinfeld, Oscar Isaac",
    description: "Miles Morales gặp gỡ một nhóm Người Nhện mới và phải đối mặt với những quan điểm khác nhau về việc trở thành người hùng đa vũ trụ.",
    poster: "https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj901a.jpg"
  },
  {
    id: "past-lives",
    title: "Past Lives", year: 2023, rating: 7.9,
    genres: ["Lãng mạn", "Chính kịch"],
    director: "Celine Song", cast: "Greta Lee, Teo Yoo, John Magaro",
    description: "Hai người bạn thời thơ ấu bị chia cách khi một gia đình di cư. Nhiều năm sau, họ gặp lại và suy ngẫm về tình yêu, số phận cùng những cuộc đời có thể đã xảy ra.",
    poster: "https://image.tmdb.org/t/p/w500/k3waqVXSnvCZWfJYNtdamTgTtTA.jpg"
  },
  {
    id: "the-batman",
    title: "The Batman", year: 2022, rating: 7.8,
    genres: ["Hành động", "Tội phạm", "Bí ẩn"],
    director: "Matt Reeves", cast: "Robert Pattinson, Zoë Kravitz, Paul Dano",
    description: "Trong năm thứ hai làm Người Dơi, Bruce Wayne lần theo dấu vết một kẻ sát nhân bí ẩn, khám phá tham nhũng và những bí mật đen tối của Gotham.",
    poster: "https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg"
  },
  {
    id: "everything-everywhere-all-at-once",
    title: "Everything Everywhere All at Once", year: 2022, rating: 7.8,
    genres: ["Khoa học viễn tưởng", "Hành động", "Hài"],
    director: "Daniel Kwan, Daniel Scheinert", cast: "Michelle Yeoh, Stephanie Hsu, Ke Huy Quan",
    description: "Một người phụ nữ nhập cư bình thường bị cuốn vào cuộc phiêu lưu đa vũ trụ, nơi cô phải kết nối với những phiên bản khác của chính mình để cứu thế giới.",
    poster: "https://image.tmdb.org/t/p/w500/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg"
  },
  {
    id: "interstellar",
    title: "Interstellar", year: 2014, rating: 8.7,
    genres: ["Khoa học viễn tưởng", "Phiêu lưu", "Chính kịch"],
    director: "Christopher Nolan", cast: "Matthew McConaughey, Anne Hathaway, Jessica Chastain",
    description: "Khi Trái Đất dần không còn khả năng nuôi sống con người, một nhóm nhà thám hiểm đi qua hố sâu vũ trụ để tìm mái nhà mới cho nhân loại.",
    poster: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg"
  },
  {
    id: "parasite",
    title: "Parasite", year: 2019, rating: 8.5,
    genres: ["Giật gân", "Chính kịch", "Hài"],
    director: "Bong Joon-ho", cast: "Song Kang-ho, Lee Sun-kyun, Cho Yeo-jeong",
    description: "Một gia đình nghèo từng bước len vào cuộc sống của gia đình giàu có, mở ra chuỗi sự kiện vừa hài hước vừa căng thẳng phơi bày khoảng cách giai cấp.",
    poster: "https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg"
  },
  {
    id: "la-la-land",
    title: "La La Land", year: 2016, rating: 8.0,
    genres: ["Nhạc kịch", "Lãng mạn", "Chính kịch"],
    director: "Damien Chazelle", cast: "Ryan Gosling, Emma Stone, John Legend",
    description: "Một nhạc công jazz và nữ diễn viên đầy tham vọng tìm thấy nhau tại Los Angeles, cùng theo đuổi ước mơ và học cách cân bằng tình yêu với sự nghiệp.",
    poster: "https://image.tmdb.org/t/p/w500/uDO8zWDhfWwoFdKS4fzkUJt0SX.jpg"
  },
  {
    id: "whiplash",
    title: "Whiplash", year: 2014, rating: 8.5,
    genres: ["Chính kịch", "Âm nhạc"],
    director: "Damien Chazelle", cast: "Miles Teller, J. K. Simmons, Paul Reiser",
    description: "Một tay trống trẻ đầy khát vọng bước vào môi trường âm nhạc khắc nghiệt dưới sự chỉ dẫn của một giáo viên nổi tiếng với phương pháp tàn nhẫn.",
    poster: "https://image.tmdb.org/t/p/w500/7fn624j5lj3xTme2SgiLCeTT8b2.jpg"
  },
  {
    id: "coco",
    title: "Coco", year: 2017, rating: 8.4,
    genres: ["Hoạt hình", "Gia đình", "Phiêu lưu"],
    director: "Lee Unkrich, Adrian Molina", cast: "Anthony Gonzalez, Gael García Bernal, Benjamin Bratt",
    description: "Miguel bước vào vùng đất của người chết trong hành trình khám phá bí mật gia đình, đồng thời theo đuổi tình yêu dành cho âm nhạc.",
    poster: "https://image.tmdb.org/t/p/w500/gGEsBPAijhVUFoiNpgZXqRVWJt2.jpg"
  },
  {
    id: "knives-out",
    title: "Knives Out", year: 2019, rating: 7.9,
    genres: ["Bí ẩn", "Hài", "Tội phạm"],
    director: "Rian Johnson", cast: "Daniel Craig, Ana de Armas, Chris Evans",
    description: "Thám tử Benoit Blanc điều tra cái chết bí ẩn của một nhà văn trinh thám giàu có, nơi mỗi thành viên trong gia đình đều có điều muốn che giấu.",
    poster: "https://image.tmdb.org/t/p/w500/pThyQovXQrw2m0s9x82twj48Jq4.jpg"
  },
  {
    id: "the-grand-budapest-hotel",
    title: "The Grand Budapest Hotel", year: 2014, rating: 8.1,
    genres: ["Hài", "Phiêu lưu", "Chính kịch"],
    director: "Wes Anderson", cast: "Ralph Fiennes, Tony Revolori, Saoirse Ronan",
    description: "Người quản lý khách sạn huyền thoại và cậu nhân viên trẻ vướng vào vụ trộm tranh, tranh chấp thừa kế và những biến động của châu Âu.",
    poster: "https://image.tmdb.org/t/p/w500/eWdyYQreja6JGCzqHWXpWHDrrPo.jpg"
  },
  {
    id: "get-out",
    title: "Get Out", year: 2017, rating: 7.8,
    genres: ["Kinh dị", "Bí ẩn", "Giật gân"],
    director: "Jordan Peele", cast: "Daniel Kaluuya, Allison Williams, Bradley Whitford",
    description: "Một chuyến thăm gia đình bạn gái dần biến thành cơn ác mộng khi Chris nhận ra những điều bất thường đáng sợ phía sau vẻ thân thiện của mọi người.",
    poster: "https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg"
  },
  {
    id: "the-lord-of-the-rings-the-fellowship-of-the-ring",
    title: "The Lord of the Rings: The Fellowship of the Ring", year: 2001, rating: 8.8,
    genres: ["Phiêu lưu", "Kỳ ảo", "Hành động"],
    director: "Peter Jackson", cast: "Elijah Wood, Ian McKellen, Viggo Mortensen",
    description: "Một người Hobbit trẻ bắt đầu chuyến hành trình nguy hiểm để phá hủy chiếc nhẫn quyền lực, cùng một hội đồng gồm những người bạn đến từ nhiều vùng đất.",
    poster: "https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg"
  },
  {
    id: "your-name",
    title: "Your Name", year: 2016, rating: 8.4,
    genres: ["Hoạt hình", "Lãng mạn", "Kỳ ảo"],
    director: "Makoto Shinkai", cast: "Ryunosuke Kamiki, Mone Kamishiraishi",
    description: "Hai thiếu niên xa lạ bất ngờ hoán đổi thân xác và cố tìm cách gặp nhau, trong câu chuyện về ký ức, thời gian và sợi dây định mệnh.",
    poster: "https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6bZrwZJ25hCB.jpg"
  }
];

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const grid = $("#movieGridCards");
const genreFilters = $("#genreFilters");
const searchInput = $("#searchInput");
const resultCount = $("#resultCount");
const emptyState = $("#emptyState");
const activeFilters = $("#activeFilters");
const modal = $("#movieModal");
let selectedGenres = new Set();
let favoriteIds = new Set();
let showFavoritesOnly = false;
let activeMovieId = null;
try { favoriteIds = new Set(JSON.parse(localStorage.getItem("frame-favorites") || "[]")); } catch (error) {}
let searchTerm = "";
let debounceTimer;
let lastFocusedElement = null;
let toastTimer;

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

function getAllGenres() {
  // Tự động phát hiện thể loại từ mảng movies, không hard-code danh sách.
  return [...new Set(movies.flatMap((movie) => movie.genres))].sort((a, b) => a.localeCompare(b, "vi"));
}

function renderGenreFilters() {
  const genres = getAllGenres();
  genreFilters.innerHTML = genres.map((genre) => {
    const count = movies.filter((movie) => movie.genres.includes(genre)).length;
    return `<label class="genre-option">
      <input type="checkbox" value="${escapeHTML(genre)}" aria-label="Lọc thể loại ${escapeHTML(genre)}">
      <span>${escapeHTML(genre)}</span><span class="genre-count">${count}</span>
    </label>`;
  }).join("");

  genreFilters.addEventListener("change", (event) => {
    if (!event.target.matches('input[type="checkbox"]')) return;
    if (event.target.checked) selectedGenres.add(event.target.value);
    else selectedGenres.delete(event.target.value);
    renderMovies();
  });
}

function getFilteredMovies() {
  const normalizedTerm = searchTerm.trim().toLocaleLowerCase("vi");
  return movies.filter((movie) => {
    const matchesSearch = movie.title.toLocaleLowerCase("vi").includes(normalizedTerm);
    // Khi chọn nhiều thể loại, hiển thị phim thuộc ÍT NHẤT MỘT thể loại được chọn.
    const matchesGenre = selectedGenres.size === 0 ||
      movie.genres.some((genre) => selectedGenres.has(genre));
    return matchesSearch && matchesGenre && (!showFavoritesOnly || favoriteIds.has(movie.id));
  });
}


function setPosterFallback(img, title) {
  if (!img || img.dataset.fallbackApplied === "true") return;
  img.dataset.fallbackApplied = "true";
  const safeTitle = String(title || "Cinema").replace(/[&<>"]/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[ch]));
  const lines = safeTitle.length > 24 ? [safeTitle.slice(0, 24), safeTitle.slice(24, 48)] : [safeTitle];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="900" viewBox="0 0 600 900"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#101b39"/><stop offset=".52" stop-color="#34216b"/><stop offset="1" stop-color="#08111f"/></linearGradient><radialGradient id="r"><stop stop-color="#6ef4ff" stop-opacity=".72"/><stop offset="1" stop-color="#8c55ff" stop-opacity="0"/></radialGradient></defs><rect width="600" height="900" fill="url(#g)"/><circle cx="390" cy="290" r="280" fill="url(#r)"/><g fill="none" stroke="#72f2ff" stroke-opacity=".7"><ellipse cx="300" cy="340" rx="230" ry="76" transform="rotate(-25 300 340)"/><circle cx="300" cy="340" r="120" stroke="#ba83ff" stroke-opacity=".7"/></g><path d="M0 690 L150 530 245 650 390 470 600 670 V900 H0Z" fill="#070b19" fill-opacity=".78"/><text x="42" y="755" fill="#70efff" font-family="Arial,sans-serif" font-size="18" letter-spacing="7">FRAME / ORIGINAL</text><text x="42" y="810" fill="#fff" font-family="Arial,sans-serif" font-size="32" font-weight="700">${lines[0]}</text>${lines[1] ? `<text x="42" y="850" fill="#fff" font-family="Arial,sans-serif" font-size="27">${lines[1]}</text>` : ""}<text x="42" y="875" fill="#a6b6dc" font-family="Arial,sans-serif" font-size="12" letter-spacing="4">CINEMA DISCOVERY</text></svg>`;
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function movieCard(movie, index) {
  const genres = movie.genres.slice(0, 2).join(" · ");
  const isFavorite = favoriteIds.has(movie.id);
  return `<article class="movie-card" tabindex="0" role="button"
      aria-label="Xem chi tiết phim ${escapeHTML(movie.title)}" data-movie-id="${escapeHTML(movie.id)}"
      style="animation-delay:${Math.min(index * 35, 280)}ms">
    <div class="poster-wrap">
      <img src="${escapeHTML(movie.poster)}" alt="Poster phim ${escapeHTML(movie.title)}"
        loading="lazy" decoding="async" referrerpolicy="no-referrer"
        onerror="setPosterFallback(this, '${escapeHTML(movie.title)}');">
      <span class="rating-pill">★ ${movie.rating.toFixed(1)}</span>
      <button class="favorite-button ${isFavorite ? "is-favorite" : ""}" data-favorite-id="${escapeHTML(movie.id)}" type="button" aria-label="${isFavorite ? "Bỏ yêu thích" : "Thêm yêu thích"}" aria-pressed="${isFavorite}">${isFavorite ? "♥" : "♡"}</button>
      <span class="poster-overlay">XEM CHI TIẾT ↗</span>
    </div>
    <div class="movie-info">
      <h3 class="movie-title" title="${escapeHTML(movie.title)}">${escapeHTML(movie.title)}</h3>
      <div class="movie-subline"><span>${movie.year}</span><span class="movie-genre">${escapeHTML(genres)}</span></div>
    </div>
  </article>`;
}

function renderActiveFilters() {
  const chips = [];
  if (searchTerm.trim()) chips.push(`Từ khóa: “${searchTerm.trim()}”`);
  selectedGenres.forEach((genre) => chips.push(genre));
  activeFilters.innerHTML = chips.map((chip) => `<span class="filter-chip">${escapeHTML(chip)}</span>`).join("");
  activeFilters.hidden = chips.length === 0;
}

function renderMovies() {
  let filteredMovies = getFilteredMovies();
  const sort = $("#sortSelect")?.value || "featured";
  if (sort === "rating") filteredMovies.sort((a,b) => b.rating - a.rating);
  if (sort === "year") filteredMovies.sort((a,b) => b.year - a.year);
  if (sort === "title") filteredMovies.sort((a,b) => a.title.localeCompare(b.title));
  grid.innerHTML = filteredMovies.map(movieCard).join("");
  resultCount.textContent = `${filteredMovies.length} / ${movies.length} bộ phim`;
  const count = $("#favoriteCount"); if (count) count.textContent = favoriteIds.size;
  const watchlist = $("#watchlistToggle"); if (watchlist) { watchlist.classList.toggle("active", showFavoritesOnly); watchlist.setAttribute("aria-pressed", String(showFavoritesOnly)); }
  emptyState.hidden = filteredMovies.length !== 0;
  grid.hidden = filteredMovies.length === 0;
  renderActiveFilters();
}

function openMovieModal(movieId) {
  const movie = movies.find((item) => item.id === movieId);
  if (!movie) return;
  activeMovieId = movieId;
  lastFocusedElement = document.activeElement;
  $("#modalPoster").src = movie.poster;
  $("#modalPoster").alt = `Poster phim ${movie.title}`;
  $("#modalPoster").onerror = function () {
    setPosterFallback(this, movie.title);
  };
  $("#modalEyebrow").textContent = `MOVIE DETAILS / ${movie.year}`;
  $("#modalTitle").textContent = movie.title;
  $("#modalMeta").innerHTML = `<span>${movie.year}</span><span class="modal-rating">★ ${movie.rating.toFixed(1)} / 10</span><span>${movie.genres.length} thể loại</span>`;
  $("#modalDescription").textContent = movie.description;
  $("#modalDirector").textContent = movie.director;
  $("#modalCast").textContent = movie.cast;
  $("#modalGenres").textContent = movie.genres.join(", ");
  updateModalFavorite();
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  $("#modalClose").focus();
}

function updateModalFavorite() {
  const button = $("#modalFavorite");
  if (!button || !activeMovieId) return;
  const saved = favoriteIds.has(activeMovieId);
  button.classList.toggle("is-favorite", saved);
  button.textContent = saved ? "♥ Đã thêm vào yêu thích" : "♡ Thêm vào yêu thích";
}

function toggleFavorite(id) {
  if (favoriteIds.has(id)) { favoriteIds.delete(id); showToast("Đã xóa khỏi danh sách yêu thích"); }
  else { favoriteIds.add(id); showToast("Đã lưu vào danh sách yêu thích"); }
  try { localStorage.setItem("frame-favorites", JSON.stringify([...favoriteIds])); } catch (error) {}
  updateModalFavorite();
  renderMovies();
}

function closeMovieModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
  if (lastFocusedElement && typeof lastFocusedElement.focus === "function") lastFocusedElement.focus();
}

function setTheme(isDark) {
  document.body.classList.toggle("dark-mode", isDark);
  $("#themeToggle").setAttribute("aria-pressed", String(isDark));
  $("#themeIcon").textContent = isDark ? "☀" : "☾";
  try { localStorage.setItem("frame-theme", isDark ? "dark" : "light"); } catch (error) {
    console.warn("Không thể lưu giao diện trong localStorage:", error);
  }
}

function loadTheme() {
  let savedTheme = "dark";
  try { savedTheme = localStorage.getItem("frame-theme") || "dark"; } catch (error) {}
  setTheme(savedTheme === "dark");
}

function clearFilters() {
  selectedGenres.clear();
  searchTerm = "";
  searchInput.value = "";
  $$('#genreFilters input[type="checkbox"]').forEach((checkbox) => { checkbox.checked = false; });
  renderMovies();
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function initSpatialTilt() {
  // Event delegation: remains active after the movie grid is re-rendered by filters/search.
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (!finePointer.matches || reduceMotion.matches) return;
  let activeCard = null;
  const resetCard = (card) => {
    if (!card) return;
    card.style.setProperty("--tilt-x", "0deg");
    card.style.setProperty("--tilt-y", "0deg");
    card.style.setProperty("--glow-x", "50%");
    card.style.setProperty("--glow-y", "30%");
  };
  grid.addEventListener("pointermove", (event) => {
    const card = event.target.closest(".movie-card");
    if (!card) { if (activeCard) resetCard(activeCard); activeCard = null; return; }
    activeCard = card;
    const rect = card.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (event.clientY - rect.top) / rect.height));
    // Small, controlled angles create depth without making text difficult to read.
    card.style.setProperty("--tilt-y", `${((x - .5) * 16).toFixed(2)}deg`);
    card.style.setProperty("--tilt-x", `${((.5 - y) * 14).toFixed(2)}deg`);
    card.style.setProperty("--glow-x", `${(x * 100).toFixed(1)}%`);
    card.style.setProperty("--glow-y", `${(y * 100).toFixed(1)}%`);
  }, { passive: true });
  grid.addEventListener("pointerleave", () => { resetCard(activeCard); activeCard = null; }, { passive: true });

  const hero = document.querySelector(".hero");
  if (hero) {
    hero.addEventListener("pointermove", (event) => {
      const rect = hero.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width;
      const y = (event.clientY - rect.top) / rect.height;
      hero.style.setProperty("--hero-ry", `${((x - .5) * 2.8).toFixed(2)}deg`);
      hero.style.setProperty("--hero-rx", `${((.5 - y) * 2.2).toFixed(2)}deg`);
    }, { passive: true });
    hero.addEventListener("pointerleave", () => {
      hero.style.setProperty("--hero-rx", "0deg");
      hero.style.setProperty("--hero-ry", "0deg");
    }, { passive: true });
  }
}

function initEvents() {
  searchInput.addEventListener("input", () => {
    clearTimeout(debounceTimer);
    const nextTerm = searchInput.value;
    debounceTimer = setTimeout(() => {
      searchTerm = nextTerm;
      renderMovies();
    }, 400); // Debounce 400ms theo yêu cầu đề.
  });

  grid.addEventListener("click", (event) => {
    const favorite = event.target.closest("[data-favorite-id]");
    if (favorite) { event.stopPropagation(); toggleFavorite(favorite.dataset.favoriteId); return; }
    const card = event.target.closest("[data-movie-id]");
    if (card) openMovieModal(card.dataset.movieId);
  });
  $("#sortSelect")?.addEventListener("change", renderMovies);
  $("#watchlistToggle")?.addEventListener("click", () => { showFavoritesOnly = !showFavoritesOnly; renderMovies(); if (showFavoritesOnly && !favoriteIds.size) showToast("Bạn chưa lưu phim yêu thích nào"); });
  $("#modalFavorite")?.addEventListener("click", () => { if (activeMovieId) toggleFavorite(activeMovieId); });
  grid.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const card = event.target.closest("[data-movie-id]");
    if (card) {
      event.preventDefault();
      openMovieModal(card.dataset.movieId);
    }
  });

  $("#themeToggle").addEventListener("click", () => {
    setTheme(!document.body.classList.contains("dark-mode"));
  });
  $("#clearFilters").addEventListener("click", clearFilters);
  $("#resetEmpty").addEventListener("click", clearFilters);
  $("#modalClose").addEventListener("click", closeMovieModal);
  modal.addEventListener("click", (event) => {
    if (event.target === modal) closeMovieModal();
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal.classList.contains("open")) closeMovieModal();
    if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) {
      event.preventDefault();
      searchInput.focus();
    }
  });
  $("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("mobile-open"));
  document.addEventListener("click", (event) => {
    const sidebar = $("#sidebar");
    if (window.innerWidth <= 820 && sidebar.classList.contains("mobile-open") &&
        !sidebar.contains(event.target) && !event.target.closest("#mobileMenu")) {
      sidebar.classList.remove("mobile-open");
    }
  });
}

function init() {
  loadTheme();
  renderGenreFilters();
  renderMovies();
  initEvents();
  initSpatialTilt();
  console.info(`Frame initialized: ${movies.length} movies, ${getAllGenres().length} genres.`);
}

document.addEventListener("DOMContentLoaded", init);
